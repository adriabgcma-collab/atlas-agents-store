# agents/template/server.py
import asyncio
import json
import os
import sys

async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    """Maneja la conexión entrante de A.T.L.A.S"""
    try:
        # 1. Recibir el mensaje de ATLAS
        data = await reader.read(4096)
        if not data:
            return
            
        request = json.loads(data.decode('utf-8'))
        
        # Logueamos en stderr para no interferir con la salida estándar
        print(f"[TEMPLATE] Petición recibida: {request.get('query', '')}", file=sys.stderr)
        
        # 2. Procesar la tarea (Aquí irá la lógica real del agente en el futuro)
        query = request.get("query", "Hola")
        response_text = f"Soy el agente Plantilla. He recibido tu consulta: '{query}'"
        
        # 3. Enviar la respuesta de vuelta a ATLAS
        response = {
            "status": "success",
            "output": response_text
        }
        
        writer.write(json.dumps(response).encode('utf-8'))
        await writer.drain()
        
    except Exception as e:
        print(f"[TEMPLATE] Error: {str(e)}", file=sys.stderr)
    finally:
        writer.close()
        await writer.wait_closed()

async def run_agent(socket_path: str):
    """Inicia el servidor de sockets en la ruta especificada"""
    # Si el archivo de socket ya existe (por un cierre brusco anterior), lo borramos
    if os.path.exists(socket_path):
        os.remove(socket_path)
        
    print(f"[TEMPLATE] Agente iniciado. Escuchando en socket: {socket_path}", file=sys.stderr)
    
    # Iniciamos el servidor Unix
    server = await asyncio.start_unix_server(handle_client, path=socket_path)
    
    async with server:
        # El agente se quedará vivo hasta que ATLAS cierre la conexión
        await server.serve_forever()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Error: Se requiere la ruta del socket como argumento.", file=sys.stderr)
        print("Uso: python server.py <ruta_al_socket>", file=sys.stderr)
        sys.exit(1)
        
    socket_path = sys.argv[1]
    try:
        asyncio.run(run_agent(socket_path))
    except KeyboardInterrupt:
        print("\n[TEMPLATE] Agente detenido.", file=sys.stderr)