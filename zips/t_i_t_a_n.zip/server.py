# agents/t_i_t_a_n/server.py
import socket
import json
import subprocess
import sys
import os
import re
import asyncio
from typing import Dict, Any, List, Optional, Callable
from pathlib import Path
from datetime import datetime
from groq import AsyncGroq
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = "llama-3.3-70b-versatile"

# Lista negra de procesos protegidos
PROCESOS_PROTEGIDOS = [
    "atlas", "python", "terminal", "finder", "systemuiserver", 
    "launchd", "kernel_task", "loginwindow", "windowserver",
    "dock", "spotlight", "mds", "syslogd", "configd"
]

# Rutas protegidas (no se pueden modificar)
RUTAS_PROTEGIDAS = [
    "/System", "/usr", "/bin", "/sbin", "/private/var",
    "/Library", "/Applications/Atlas"
]

class ComandoRegistry:
    """Registro centralizado de comandos disponibles"""
    
    def __init__(self):
        self.comandos: Dict[str, Callable] = {}
        self.descripciones: Dict[str, str] = {}
    
    def registrar(self, nombre: str, descripcion: str):
        """Decorador para registrar comandos"""
        def decorator(func):
            self.comandos[nombre] = func
            self.descripciones[nombre] = descripcion
            return func
        return decorator
    
    def obtener(self, nombre: str) -> Optional[Callable]:
        return self.comandos.get(nombre)
    
    def listar(self) -> List[Dict[str, str]]:
        return [
            {"nombre": nombre, "descripcion": self.descripciones[nombre]}
            for nombre in self.comandos.keys()
        ]

# Instancia global del registro
registry = ComandoRegistry()

class TitanAgent:
    def __init__(self):
        self.groq_client = AsyncGroq(api_key=GROQ_API_KEY) if GROQ_API_KEY else None
        self._registrar_comandos()
    
    def _registrar_comandos(self):
        """Registra todos los 24 comandos disponibles"""
        
        # ========== CONTROL DE SAFARI ==========
        @registry.registrar("safari_abrir", "Abre Safari")
        async def safari_abrir(params: Dict) -> Dict:
            return await self._ejecutar_applescript('tell application "Safari" to activate')
        
        @registry.registrar("safari_navegar", "Navega a una URL en Safari")
        async def safari_navegar(params: Dict) -> Dict:
            url = params.get("url", "https://www.google.com")
            if not url.startswith("http"):
                url = "https://" + url
            script = f'tell application "Safari"\nactivate\nopen location "{url}"\nend tell'
            return await self._ejecutar_applescript(script)
        
        # ========== GESTIÓN DE ARCHIVOS ==========
        @registry.registrar("archivo_crear", "Crea un archivo con contenido")
        async def archivo_crear(params: Dict) -> Dict:
            ruta = params.get("ruta")
            contenido = params.get("contenido", "")
            if not ruta:
                return {"exito": False, "error": "Falta la ruta del archivo"}
            
            ruta_expandida = Path(ruta).expanduser()
            if self._es_ruta_protegida(str(ruta_expandida)):
                return {"exito": False, "error": "No se puede crear archivos en rutas protegidas"}
            
            try:
                ruta_expandida.parent.mkdir(parents=True, exist_ok=True)
                ruta_expandida.write_text(contenido, encoding="utf-8")
                return {"exito": True, "mensaje": f"Archivo creado: {ruta_expandida}"}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("archivo_mover", "Mueve un archivo o carpeta")
        async def archivo_mover(params: Dict) -> Dict:
            origen = params.get("origen")
            destino = params.get("destino")
            if not origen or not destino:
                return {"exito": False, "error": "Faltan origen o destino"}
            
            origen_exp = Path(origen).expanduser()
            destino_exp = Path(destino).expanduser()
            
            if self._es_ruta_protegida(str(origen_exp)) or self._es_ruta_protegida(str(destino_exp)):
                return {"exito": False, "error": "No se puede mover archivos en rutas protegidas"}
            
            if not origen_exp.exists():
                return {"exito": False, "error": f"El origen no existe: {origen_exp}"}
            
            try:
                destino_exp.parent.mkdir(parents=True, exist_ok=True)
                origen_exp.rename(destino_exp)
                return {"exito": True, "mensaje": f"Movido de {origen_exp} a {destino_exp}"}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("archivo_buscar", "Busca archivos que coincidan con un patrón")
        async def archivo_buscar(params: Dict) -> Dict:
            patron = params.get("patron")
            directorio = params.get("directorio", os.path.expanduser("~"))
            if not patron:
                return {"exito": False, "error": "Falta el patrón de búsqueda"}
            
            directorio_exp = Path(directorio).expanduser()
            try:
                archivos_encontrados = list(directorio_exp.rglob(patron))
                archivos = [str(f) for f in archivos_encontrados if f.is_file()][:20]
                
                if not archivos:
                    return {"exito": True, "mensaje": "No se encontraron archivos", "archivos": []}
                
                return {"exito": True, "mensaje": f"Encontrados {len(archivos)} archivos", "archivos": archivos}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        # ========== GESTIÓN DE CARPETAS ==========
        @registry.registrar("carpeta_crear", "Crea una carpeta")
        async def carpeta_crear(params: Dict) -> Dict:
            ruta = params.get("ruta")
            if not ruta:
                return {"exito": False, "error": "Falta la ruta de la carpeta"}
            
            ruta_expandida = Path(ruta).expanduser()
            if self._es_ruta_protegida(str(ruta_expandida)):
                return {"exito": False, "error": "No se puede crear carpetas en rutas protegidas"}
            
            try:
                ruta_expandida.mkdir(parents=True, exist_ok=True)
                return {"exito": True, "mensaje": f"Carpeta creada: {ruta_expandida}"}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("carpeta_listar", "Lista el contenido de una carpeta")
        async def carpeta_listar(params: Dict) -> Dict:
            ruta = params.get("ruta", os.path.expanduser("~"))
            ruta_expandida = Path(ruta).expanduser()
            
            if not ruta_expandida.exists():
                return {"exito": False, "error": f"La carpeta no existe: {ruta_expandida}"}
            
            try:
                contenido = []
                for item in ruta_expandida.iterdir():
                    tipo = "carpeta" if item.is_dir() else "archivo"
                    contenido.append({"nombre": item.name, "tipo": tipo})
                
                return {"exito": True, "mensaje": f"Contenido de {ruta_expandida}", "contenido": contenido}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        # ========== CONTROL DE APLICACIONES ==========
        @registry.registrar("app_abrir", "Abre una aplicación")
        async def app_abrir(params: Dict) -> Dict:
            nombre_app = params.get("nombre")
            if not nombre_app:
                return {"exito": False, "error": "Falta el nombre de la aplicación"}
            if nombre_app.lower() in PROCESOS_PROTEGIDOS:
                return {"exito": False, "error": f"No puedo abrir procesos protegidos: {nombre_app}"}
            
            script = f'tell application "{nombre_app}" to activate'
            return await self._ejecutar_applescript(script)
        
        @registry.registrar("app_cerrar", "Cierra una aplicación")
        async def app_cerrar(params: Dict) -> Dict:
            nombre_app = params.get("nombre")
            if not nombre_app:
                return {"exito": False, "error": "Falta el nombre de la aplicación"}
            if nombre_app.lower() in PROCESOS_PROTEGIDOS:
                return {"exito": False, "error": f"No puedo cerrar procesos protegidos: {nombre_app}"}
            
            script = f'tell application "{nombre_app}" to quit'
            return await self._ejecutar_applescript(script)
        
        # ========== CONTROL DEL SISTEMA ==========
        @registry.registrar("sistema_volumen", "Cambia el volumen del sistema (0-100)")
        async def sistema_volumen(params: Dict) -> Dict:
            nivel = params.get("nivel", 50)
            nivel = max(0, min(100, int(nivel)))
            script = f"set volume output volume {nivel}"
            return await self._ejecutar_applescript(script)
        
        @registry.registrar("sistema_brillo", "Cambia el brillo de pantalla (0-100)")
        async def sistema_brillo(params: Dict) -> Dict:
            nivel = params.get("nivel", 50)
            nivel = max(0, min(100, int(nivel)))
            script = f"tell application \"System Events\" to set brightness to {nivel / 100}"
            return await self._ejecutar_applescript(script)
        
        @registry.registrar("sistema_bateria", "Muestra el nivel de batería")
        async def sistema_bateria(params: Dict) -> Dict:
            try:
                resultado = subprocess.run(["pmset", "-g", "batt"], capture_output=True, text=True, timeout=5)
                return {"exito": True, "mensaje": "Estado de batería", "datos": resultado.stdout}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("sistema_info", "Obtiene información del sistema")
        async def sistema_info(params: Dict) -> Dict:
            info = {}
            try:
                cpu = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True, timeout=5)
                info["cpu"] = cpu.stdout.strip()
                
                mem = subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True, timeout=5)
                info["memoria_total"] = f"{int(mem.stdout.strip()) / (1024**3):.1f} GB"
                
                disco = subprocess.run(["df", "-h", "/"], capture_output=True, text=True, timeout=5)
                lineas = disco.stdout.strip().split("\n")
                if len(lineas) > 1:
                    partes = lineas[1].split()
                    info["disco_usado"] = partes[2]
                    info["disco_disponible"] = partes[3]
                
                return {"exito": True, "mensaje": "Información del sistema", "datos": info}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("sistema_wifi", "Activa/desactiva WiFi o muestra red actual")
        async def sistema_wifi(params: Dict) -> Dict:
            accion = params.get("accion", "estado")  # estado, activar, desactivar
            
            try:
                if accion == "activar":
                    subprocess.run(["networksetup", "-setairportpower", "en0", "on"], check=True, timeout=5)
                    return {"exito": True, "mensaje": "WiFi activado"}
                elif accion == "desactivar":
                    subprocess.run(["networksetup", "-setairportpower", "en0", "off"], check=True, timeout=5)
                    return {"exito": True, "mensaje": "WiFi desactivado"}
                else:
                    resultado = subprocess.run(["networksetup", "-getairportnetwork", "en0"], capture_output=True, text=True, timeout=5)
                    return {"exito": True, "mensaje": "Red WiFi actual", "datos": resultado.stdout}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("sistema_bluetooth", "Activa/desactiva Bluetooth")
        async def sistema_bluetooth(params: Dict) -> Dict:
            accion = params.get("accion", "activar")  # activar, desactivar
            
            try:
                estado = "on" if accion == "activar" else "off"
                subprocess.run(["blueutil", "--power", estado], check=True, timeout=5)
                return {"exito": True, "mensaje": f"Bluetooth {accion}do"}
            except Exception as e:
                return {"exito": False, "error": f"{str(e)} (Nota: requiere blueutil instalado con brew)"}
        
        @registry.registrar("sistema_captura", "Hace captura de pantalla")
        async def sistema_captura(params: Dict) -> Dict:
            tipo = params.get("tipo", "pantalla")  # pantalla, seleccion
            ruta = params.get("ruta", os.path.expanduser("~/Desktop/captura.png"))
            
            try:
                if tipo == "seleccion":
                    subprocess.run(["screencapture", "-i", ruta], check=True, timeout=30)
                else:
                    subprocess.run(["screencapture", ruta], check=True, timeout=10)
                
                return {"exito": True, "mensaje": f"Captura guardada en: {ruta}"}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("sistema_notificacion", "Muestra notificación nativa de macOS")
        async def sistema_notificacion(params: Dict) -> Dict:
            titulo = params.get("titulo", "A.T.L.A.S")
            mensaje = params.get("mensaje", "Notificación del sistema")
            
            script = f'display notification "{mensaje}" with title "{titulo}"'
            return await self._ejecutar_applescript(script)
        
        # ========== GESTIÓN DE PROCESOS ==========
        @registry.registrar("proceso_listar", "Lista procesos activos")
        async def proceso_listar(params: Dict) -> Dict:
            filtro = params.get("filtro", "")
            
            try:
                comando = "ps aux"
                if filtro:
                    comando += f" | grep -i {filtro}"
                
                resultado = subprocess.run(comando, shell=True, capture_output=True, text=True, timeout=10)
                lineas = resultado.stdout.strip().split("\n")[:20]
                
                return {"exito": True, "mensaje": f"Procesos encontrados: {len(lineas)}", "procesos": lineas}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("proceso_matar", "Mata un proceso por nombre")
        async def proceso_matar(params: Dict) -> Dict:
            nombre = params.get("nombre")
            
            if not nombre:
                return {"exito": False, "error": "Falta el nombre del proceso"}
            
            if nombre.lower() in PROCESOS_PROTEGIDOS:
                return {"exito": False, "error": f"No puedo matar procesos protegidos: {nombre}"}
            
            try:
                subprocess.run(["pkill", "-f", nombre], check=True, timeout=5)
                return {"exito": True, "mensaje": f"Proceso {nombre} terminado"}
            except subprocess.CalledProcessError:
                return {"exito": False, "error": f"No se encontró el proceso: {nombre}"}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        # ========== RED AVANZADA ==========
        @registry.registrar("red_ping", "Hace ping a una dirección")
        async def red_ping(params: Dict) -> Dict:
            direccion = params.get("direccion")
            if not direccion:
                return {"exito": False, "error": "Falta la dirección"}
            
            try:
                resultado = subprocess.run(["ping", "-c", "4", direccion], capture_output=True, text=True, timeout=10)
                return {"exito": True, "mensaje": f"Ping a {direccion}", "resultado": resultado.stdout}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("red_ip_publica", "Obtiene tu IP pública")
        async def red_ip_publica(params: Dict) -> Dict:
            try:
                resultado = subprocess.run(["curl", "-s", "ifconfig.me"], capture_output=True, text=True, timeout=10)
                return {"exito": True, "mensaje": "Tu IP pública", "ip": resultado.stdout.strip()}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        # ========== FINDER Y VENTANAS ==========
        @registry.registrar("finder_abrir", "Abre una carpeta en Finder")
        async def finder_abrir(params: Dict) -> Dict:
            ruta = params.get("ruta", os.path.expanduser("~"))
            ruta_expandida = Path(ruta).expanduser()
            
            if not ruta_expandida.exists():
                return {"exito": False, "error": f"La carpeta no existe: {ruta_expandida}"}
            
            script = f'tell application "Finder" to open POSIX file "{ruta_expandida}"'
            return await self._ejecutar_applescript(script)
        
        @registry.registrar("ventana_minimizar", "Minimiza la ventana activa")
        async def ventana_minimizar(params: Dict) -> Dict:
            script = 'tell application "System Events" to keystroke "m" using command down'
            return await self._ejecutar_applescript(script)
        
        # ========== CONTROL DE MEDIOS ==========
        @registry.registrar("media_play_pause", "Play/Pausa en reproductor de medios")
        async def media_play_pause(params: Dict) -> Dict:
            script = 'tell application "System Events" to keystroke space'
            return await self._ejecutar_applescript(script)
        
        @registry.registrar("media_siguiente", "Siguiente canción/track")
        async def media_siguiente(params: Dict) -> Dict:
            script = 'tell application "System Events" to key code 124 using {command down, option down}'
            return await self._ejecutar_applescript(script)
        
        @registry.registrar("media_anterior", "Canción/track anterior")
        async def media_anterior(params: Dict) -> Dict:
            script = 'tell application "System Events" to key code 123 using {command down, option down}'
            return await self._ejecutar_applescript(script)
        
        # ========== PORTAPAPELES ==========
        @registry.registrar("portapapeles_leer", "Lee el contenido del portapapeles")
        async def portapapeles_leer(params: Dict) -> Dict:
            try:
                resultado = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5)
                return {"exito": True, "mensaje": "Contenido del portapapeles", "contenido": resultado.stdout[:500]}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        @registry.registrar("portapapeles_escribir", "Copia texto al portapapeles")
        async def portapapeles_escribir(params: Dict) -> Dict:
            texto = params.get("texto", "")
            if not texto:
                return {"exito": False, "error": "Falta el texto"}
            
            try:
                proceso = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
                proceso.communicate(texto.encode('utf-8'))
                return {"exito": True, "mensaje": "Texto copiado al portapapeles"}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        # ========== TERMINAL ==========
        @registry.registrar("terminal_ejecutar", "Ejecuta un comando de terminal")
        async def terminal_ejecutar(params: Dict) -> Dict:
            comando = params.get("comando")
            if not comando:
                return {"exito": False, "error": "Falta el comando"}
            
            comandos_peligrosos = ["rm -rf /", "mkfs", "dd if=", ":(){:|:&};:", "sudo rm"]
            if any(peligro in comando for peligro in comandos_peligrosos):
                return {"exito": False, "error": "Comando potencialmente peligroso bloqueado"}
            
            try:
                resultado = subprocess.run(comando, shell=True, capture_output=True, text=True, timeout=15)
                return {
                    "exito": True,
                    "mensaje": "Comando ejecutado",
                    "stdout": resultado.stdout[:1000],
                    "stderr": resultado.stderr[:500],
                    "codigo_retorno": resultado.returncode
                }
            except subprocess.TimeoutExpired:
                return {"exito": False, "error": "El comando tardó demasiado (timeout de 15s)"}
            except Exception as e:
                return {"exito": False, "error": str(e)}
        
        # ========== UTILIDADES ==========
        @registry.registrar("utilidad_fecha", "Muestra fecha y hora actual")
        async def utilidad_fecha(params: Dict) -> Dict:
            formato = params.get("formato", "%Y-%m-%d %H:%M:%S")
            ahora = datetime.now().strftime(formato)
            return {"exito": True, "mensaje": f"Fecha y hora: {ahora}"}
    
    def _es_ruta_protegida(self, ruta: str) -> bool:
        """Verifica si una ruta está protegida"""
        ruta_abs = str(Path(ruta).resolve())
        return any(ruta_abs.startswith(protegida) for protegida in RUTAS_PROTEGIDAS)
    
    async def _ejecutar_applescript(self, script: str) -> Dict:
        """Ejecuta un script de AppleScript"""
        try:
            resultado = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=10)
            if resultado.returncode == 0:
                return {"exito": True, "mensaje": resultado.stdout.strip() or "Comando ejecutado correctamente"}
            else:
                return {"exito": False, "error": resultado.stderr}
        except subprocess.TimeoutExpired:
            return {"exito": False, "error": "El script tardó demasiado"}
        except Exception as e:
            return {"exito": False, "error": str(e)}
    
    async def analizar_query_con_groq(self, query: str) -> List[Dict]:
        """Usa Groq para analizar la query y devolver un plan de ejecución"""
        
        if not self.groq_client:
            return [{"comando": "terminal_ejecutar", "params": {"comando": "echo 'API Key faltante'"}}]
        
        comandos_str = "\n".join([f"- {c['nombre']}: {c['descripcion']}" for c in registry.listar()])
        prompt = f"""Eres T.I.T.A.N, un asistente que controla el sistema macOS.
El usuario te pide que hagas algo y tú debes devolver un plan de ejecución en formato JSON.

Comandos disponibles:
{comandos_str}

REGLAS IMPORTANTES:
1. Devuelve SIEMPRE un array JSON de comandos a ejecutar.
2. Cada comando debe tener: "comando" (nombre) y "params" (diccionario).
3. Devuelve SOLO el array JSON, sin markdown, sin explicaciones.
4. Para rutas de macOS, traduce nombres comunes a rutas absolutas:
   - "Escritorio" → "/Users/adria/Desktop"
   - "Documentos" → "/Users/adria/Documents"
   - "Descargas" → "/Users/adria/Downloads"
   - "Inicio" o "Home" → "/Users/adria"
   - Usa "~" para el home del usuario

Ejemplos:
Usuario: "abre Safari"
Respuesta: [{{"comando": "safari_abrir", "params": {{}}}}]

Usuario: "baja el brillo al 30%"
Respuesta: [{{"comando": "sistema_brillo", "params": {{"nivel": 30}}}}]

Usuario: "crea una carpeta llamada 'Prueba' en el Escritorio"
Respuesta: [{{"comando": "carpeta_crear", "params": {{"ruta": "/Users/adria/Desktop/Prueba"}}}}]

Usuario: "crea un archivo en el Escritorio llamado 'test.txt' con el contenido 'hola'"
Respuesta: [{{"comando": "archivo_crear", "params": {{"ruta": "/Users/adria/Desktop/test.txt", "contenido": "hola"}}}}]

Usuario: "copia 'hola mundo' al portapapeles"
Respuesta: [{{"comando": "portapapeles_escribir", "params": {{"texto": "hola mundo"}}}}]

Usuario: "{query}"
Respuesta:"""
        
        try:
            response = await self.groq_client.chat.completions.create(
                model=GROQ_MODEL,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=1000
            )
            
            content = response.choices[0].message.content.strip()
            content = content.replace("```json", "").replace("```", "").strip()
            
            match = re.search(r'\[.*\]', content, re.DOTALL)
            if match:
                return json.loads(match.group())
            else:
                print(f"Groq no devolvió JSON válido. Contenido: {content}", flush=True)
                return [{"comando": "terminal_ejecutar", "params": {"comando": f"echo 'No se pudo interpretar la petición'"}}]
        
        except Exception as e:
            print(f"Error en Groq: {e}", flush=True)
            return [{"comando": "terminal_ejecutar", "params": {"comando": f"echo 'Error de IA: {str(e)}'"}}]
    
    async def procesar_query(self, query: str) -> str:
        """Procesa la query del usuario: analiza con Groq y ejecuta el plan"""
        
        plan = await self.analizar_query_con_groq(query)
        resultados = []
        
        for paso in plan:
            comando_nombre = paso.get("comando")
            params = paso.get("params", {})
            
            comando_func = registry.obtener(comando_nombre)
            
            if not comando_func:
                resultados.append(f"❌ Comando desconocido: {comando_nombre}")
                continue
            
            try:
                resultado = await comando_func(params)
                if resultado.get("exito"):
                    mensaje = resultado.get('mensaje', 'Comando ejecutado')
                    
                    # Detectar campos adicionales y mostrarlos
                    datos_extra = []
                    if "datos" in resultado:
                        datos_extra.append(str(resultado["datos"]))
                    if "procesos" in resultado:
                        datos_extra.append("\n".join(resultado["procesos"][:10]))
                    if "ip" in resultado:
                        datos_extra.append(resultado["ip"])
                    if "contenido" in resultado:
                        datos_extra.append(resultado["contenido"])
                    if "stdout" in resultado and resultado["stdout"]:
                        datos_extra.append(resultado["stdout"])
                    if "archivos" in resultado:
                        datos_extra.append("\n".join(resultado["archivos"]))
                    if "contenido" in resultado and isinstance(resultado["contenido"], list):
                        items = [f"{item['nombre']} ({item['tipo']})" for item in resultado["contenido"][:15]]
                        datos_extra.append("\n".join(items))
                    
                    if datos_extra:
                        mensaje += f"\n{chr(10).join(datos_extra)}"
                    
                    resultados.append(f"✅ {mensaje}")
                else:
                    resultados.append(f"❌ Error en {comando_nombre}: {resultado.get('error', 'Error desconocido')}")
            except Exception as e:
                resultados.append(f"❌ Error ejecutando {comando_nombre}: {str(e)}")
        
        return "\n".join(resultados) if resultados else "No pude entender la petición."
    
    def start_unix_server(self, socket_path: str):
        """Inicia servidor socket UNIX (ciclo de vida efímero: atiende 1 petición y muere)"""
        if os.path.exists(socket_path):
            os.remove(socket_path)
        
        server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        server.bind(socket_path)
        server.listen(1)
        print(f"T.I.T.A.N listo en {socket_path}", flush=True)
        
        try:
            conn, _ = server.accept()
            try:
                data = conn.recv(65536)
                if data:
                    request = json.loads(data.decode('utf-8'))
                    query = request.get("query", "")
                    print(f"T.I.T.A.N recibió query: {query}", flush=True)
                    
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    response_text = loop.run_until_complete(self.procesar_query(query))
                    loop.close()
                    
                    print(f"T.I.T.A.N generó respuesta: {response_text}", flush=True)
                    
                    # Enviamos múltiples claves por compatibilidad
                    payload = {
                        "response": response_text,
                        "output": response_text,
                        "respuesta": response_text,
                        "status": "success"
                    }
                    
                    conn.sendall(json.dumps(payload).encode('utf-8'))
                    print("T.I.T.A.N envió payload correctamente.", flush=True)
                else:
                    print("T.I.T.A.N: No se recibieron datos.", flush=True)
                    conn.sendall(json.dumps({"response": "Error: No se recibieron datos", "output": "Error: No se recibieron datos"}).encode('utf-8'))
            except Exception as e:
                print(f"T.I.T.A.N Error en conexión: {e}", flush=True)
                conn.sendall(json.dumps({"response": str(e), "output": str(e)}).encode('utf-8'))
            finally:
                conn.close()
        except Exception as e:
            print(f"T.I.T.A.N Error en servidor: {e}", flush=True)
        finally:
            server.close()
            if os.path.exists(socket_path):
                os.remove(socket_path)
            print("T.I.T.A.N finalizado y limpiado.", flush=True)
            sys.exit(0)

if __name__ == "__main__":
    socket_path = sys.argv[1] if len(sys.argv) > 1 else "/tmp/titan_test.sock"
    agent = TitanAgent()
    agent.start_unix_server(socket_path)